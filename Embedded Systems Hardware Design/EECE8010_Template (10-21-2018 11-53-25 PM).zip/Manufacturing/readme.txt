Readme.txt file for the Manufacturing directory.

Student Names: Lisler Thomson Pulikkottil
Student Numbers: 8212565
Phone Contact Information: 2268085653
Board Size: 6x4 inches

